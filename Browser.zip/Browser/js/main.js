async function cacheAndPlay(url) {
  const cache = await caches.open('media-cache');
  await cache.add(url);
  window.location.href = `/player.html?src=${encodeURIComponent(url)}`;
}