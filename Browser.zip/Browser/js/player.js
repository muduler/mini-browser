(async () => {
  const params = new URLSearchParams(location.search);
  const src = params.get('src');

  const cache = await caches.open('media-cache');
  const response = await cache.match(src);
  const blob = await response.blob();
  const videoURL = URL.createObjectURL(blob);

  document.getElementById('video').src = videoURL;
})();